def Ok(i):  # 检查有连接的点，是否颜色不同
    for j in range(1, i):
        if a[i][j] == 1 and x[i] == x[j]:
            return False
    return True


def backtrack(i):
    global m, n, colors, sum1, a, x
    if i > n:
        sum1 += 1
        colors.append(x[:])
        return
    for j in range(1, m + 1):
        x[i] = j
        if (Ok(i)):
            backtrack(i + 1)


a = [[0, 0, 0, 0, 0, 0], [0, 0, 1, 1, 0, 0], [0, 1, 0, 1, 1, 1], [0, 1, 1, 0, 1, 0], [0, 0, 1, 1, 0, 1],
     [0, 0, 1, 0, 1, 0]]
n = len(a) - 1
m = 3
sum1 = 0
colors = []
x = [0 for i in range(n + 1)]
backtrack(1)
for i in range(len(colors)):
    print(colors[i])
print("共有：" + str(sum1) + "种着色方案")
