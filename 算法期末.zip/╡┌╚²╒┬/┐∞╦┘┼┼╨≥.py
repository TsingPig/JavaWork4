def quickSort(l, r):
    if l < r:
        pivot = partition(l, r)
        quickSort(l, pivot - 1)
        quickSort(pivot + 1, r)


def partition(l, r):
    global a
    i, j = l, r
    tmp = a[l]
    while i < j:
        while i < j and a[j] >= tmp:
            j -= 1
        if i < j:
            a[i], a[j] = a[j], a[i]
            i += 1
        while i < j and a[i] <= tmp:
            i += 1
        if i < j:
            a[i], a[j] = a[j], a[i]
            j -= 1
    return i


a = [54, 26, 93, 17, 77, 31, 44, 55, 20]
n = len(a)
quickSort(0, n - 1)
print("排序后的数组:")
print(a)
