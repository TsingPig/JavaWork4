def pre_order(tree, root):
    if root >= len(tree) or tree[root] == '?':  # 遍历完成、或者遇到结束标记
        return
    print(tree[root], end=' ')
    pre_order(tree, 2 * root + 1)
    pre_order(tree, 2 * root + 2)


def mid_order(tree, root):
    if root >= len(tree) or tree[root] == '?':
        return
    mid_order(tree, 2 * root + 1)
    print(tree[root], end=' ')
    mid_order(tree, 2 * root + 2)


def post_order(tree, root):
    if root >= len(tree) or tree[root] == '?':
        return
    post_order(tree, 2 * root + 1)
    post_order(tree, 2 * root + 2)
    print(tree[root], end=' ')


tree = "CBGADH???EF"
# tree = "-*++23*35????52"
print("Pre Order Traversal:")
pre_order(tree, 0)
print("\nMid Order Traversal:")
mid_order(tree, 0)
print("\nPost Order Traversal:")
post_order(tree, 0)
