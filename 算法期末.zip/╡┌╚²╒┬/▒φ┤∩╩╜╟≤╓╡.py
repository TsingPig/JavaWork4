# 后缀表达式求值
def prefix(pre):
    Opd = []
    for i in range(len(pre) - 1, -1, -1):
        if pre[i].isdigit():
            Opd.append(int(pre[i]))
        else:
            d1 = Opd.pop()
            d2 = Opd.pop()
            Opd.append(Cal(d1, pre[i], d2))
    return Opd.pop()


# 后缀表达式求值
def postfix(post):
    Opd = []
    for i in range(len(post)):
        if post[i].isdigit():
            Opd.append(int(post[i]))
        else:
            d2 = Opd.pop()
            d1 = Opd.pop()
            Opd.append(Cal(d1, post[i], d2))
    return Opd.pop()

def Cal(d1, op, d2):
    if op == '+':
        return d1 + d2
    if op == '-':
        return d1 - d2
    if op == '*':
        return d1 * d2
    if op == '/':
        return d1 / d2


pre = "-53"
post = "35+2*352*+-"

print("Prefix:")
print(prefix(pre))
