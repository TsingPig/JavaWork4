def move(A, B):
    print(A + "->" + B)


def hanoi(n, A, B, C):
    if n == 1:
        move(A, C)
        return
    hanoi(n - 1, A, C, B)
    move(A, C)
    hanoi(n - 1, B, A, C)


hanoi(3, 'A', 'B', 'C')
