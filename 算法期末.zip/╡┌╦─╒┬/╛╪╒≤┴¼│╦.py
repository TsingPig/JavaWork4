import math

import numpy as np


def MatrixChain(p, n):  # p表示矩阵的规模，p[i]表示第i个矩阵的列数，第i+1个矩阵的行数
    # 存储最优解
    m = np.full((n + 1, n + 1), math.inf)  # 牺牲第0行、第0列
    # 存储最优分割策略
    s = np.zeros((n + 1, n + 1))
    for i in range(n + 1):
        m[i][i] = 0
        s[i][i] = 0
    for r in range(2, n + 1):  # r控制问题规模,应该遍历每一个起始位置i 从[1,n-r+1]
        for i in range(1, n - r + 2):  # 起始位置
            j = i + r - 1  # 终止位置，子问题为Ai...Aj
            for k in range(i, j):  # 遍历每一种划分方式
                t = m[i][k] + m[k + 1][j] + p[i - 1] * p[k] * p[j]
                if t < m[i][j]:
                    m[i][j] = t
                    s[i][j] = k
    return m, s


def backtrack(i, j, s):  # 根据划分方式s，求得最优加括号的字符串
    global res
    if i == j:
        res.append('A' + str(i))
        return
    res.append('(')
    backtrack(i, int(s[i][j]), s)
    backtrack(int(s[i][j]) + 1, j, s)
    res.append(')')


arr = [[3, 2], [2, 5], [5, 10], [10, 2], [2, 3]]
n = len(arr)
res = []
# 处理矩阵的行和列
p = []
for i in range(n):
    if i == 0:
        p.append(arr[0][0])
        p.append(arr[0][1])
    else:
        p.append(arr[i][1])
m, s = MatrixChain(p, n)
backtrack(1, n, s)
print(''.join(res))
print(m[1][5])
