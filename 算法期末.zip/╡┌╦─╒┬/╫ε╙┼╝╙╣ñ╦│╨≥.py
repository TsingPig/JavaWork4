class Job:
    def __init__(self, idx, key, N1):  # N1==a[i]<b[i]
        self.idx = idx
        self.key = key
        self.N1 = N1

    def __lt__(self, other):
        return self.key < other.key

    def __eq__(self, other):
        return self.key == other.key


def FlowShop(n, a, b):
    # a,b分别表示在两种机器上的加工时间向量
    x = [0] * n  # 最终加工顺序
    job = [Job(i, min(a[i], b[i]), a[i] < b[i]) for i in range(n)]
    job.sort()  # 按照Key进行排序（Johnson不等式)
    l, r = 0, n - 1
    for i in range(n):
        if job[i].N1:
            x[l] = job[i].idx
            l += 1
        else:
            x[r] = job[i].idx
            r -= 1
    f1 = t = 0  # f1代表第一个机器上完成的时间，t代表全部工件加工完成时间
    for i in range(n):
        f1 += a[x[i]]
        if f1 < t:  # 挤压
            t += b[x[i]]
        else:  # 空闲，需要等
            t = f1 + b[x[i]]
    return x, t


a = [3, 8, 10, 12, 6, 9, 15]
b = [7, 2, 6, 18, 3, 10, 4]
n = len(a)
x, t = FlowShop(n, a, b)
print(t)
print("最优加工次序为：")
for i in range(n):
    print(x[i] + 1, end='  ')
