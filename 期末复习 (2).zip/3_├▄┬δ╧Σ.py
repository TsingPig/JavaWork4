def backtrack(i):
    if i == n:
        print(x)
        return
    for j in range(i, n):
        x[i], x[j] = x[j], x[i]
        backtrack(i + 1)
        x[i], x[j] = x[j], x[i]


n = 3
x = [2, 5, 6]
backtrack(0)
