def backtrack(n, board, i):
    if i >= n:
        print(board)
        return
    for j in range(n):
        if is_valid(board, i, j):
            board[i] = j
            backtrack(n, board, i + 1)


def is_valid(board, i, j):
    for k in range(i):
        if board[k]==j or abs(i-k)==abs(j-board[k]):
            return False
    return True


def n_queens(n):
    board = [-1] * n
    backtrack(n, board, 0)


n_queens(4)
