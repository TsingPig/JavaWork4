import numpy as np


def LCS(A, B):
    n = len(A)
    m = len(B)
    # 牺牲0位置
    A.insert(0, '0')
    B.insert(0, '0')
    # c[i][j]存储A[1:i]和B[1:j] 公共子序列长度
    c = np.zeros((n + 1, m + 1), int)
    b = np.zeros((n + 1, m + 1), int)
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            if A[i] == B[j]:
                c[i][j] = c[i - 1][j - 1] + 1
                b[i][j] = 0
            elif c[i][j - 1] >= c[i - 1][j]:
                c[i][j] = c[i][j - 1]
                b[i][j] = -1
            else:
                c[i][j] = c[i - 1][j]
                b[i][j] = 1
    return c, b


def printLCS(b, A, i, j):
    global res
    if i == 0 or j == 0:  # 终止条件
        return
    if b[i][j] == 0:  # 说明A[i]==B[j]
        printLCS(b, A, i - 1, j - 1)
        res.append(A[i])
    elif b[i][j] == -1:
        printLCS(b, A, i, j - 1)
    else:
        printLCS(b, A, i - 1, j)


A = ['z', 'x', 'y', 'x', 'y', 'z']
B = ['x', 'y', 'y', 'z', 'x']
res = []
n = len(A)
m = len(B)
c, b = LCS(A, B)
printLCS(b, A, n, m)
print(res)
print(c[n][m])
