import numpy as np


def knapsack(w, v, W):  # return max v,x
    n = len(w)  # n存放物体的个数
    w.insert(0, 0)
    v.insert(0, 0)  # 牺牲下标0
    dp = np.zeros((n + 1, W + 1), int)
    for i in range(1, n + 1):
        for j in range(1, W + 1):
            if w[i] <= j:  # 可以放
                dp[i][j] = max(dp[i - 1][j], dp[i - 1][j - w[i]] + v[i])
            else:
                dp[i][j] = dp[i - 1][j]
    x = [0] * (n + 1)  # 存放方式
    j = W
    for i in range(n, 0, -1):
        if dp[i][j] != dp[i - 1][j]:  # 选了
            x[i] = 1
            j -= w[i]
    return dp[n][W], x[1:]


w = [2, 2, 6, 5, 4]
v = [3, 6, 5, 4, 6]
W = 10
bestp, x = knapsack(w, v, W)
print('最大价值为：', bestp)
print('背包中所装物品为:', x)
