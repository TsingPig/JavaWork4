def backtrack(i):
    global bestV, bestX, cv, cw, x
    if i == n:
        if bestV < cv:
            bestV = cv
            bestX = x[:]
        return
    if cw + w[i] < W:  # 可以拿
        x[i] = 1
        cw += w[i]
        cv += v[i]
        backtrack(i + 1)
        cw -= w[i]
        cv -= v[i]
    x[i] = 0
    backtrack(i + 1)


bestV = 0
cw = 0
cv = 0
bestX = None
n = 5
W = 10
w = [2, 2, 6, 5, 4]
v = [6, 3, 5, 4, 6]  # 价值

x = [0] * n  # 解空间
backtrack(0)
print(bestV)
print(bestX)
