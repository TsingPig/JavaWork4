import math


def backtrack(i):
    global x, bestx, bestf, f1, f  # f1代表第一台机器完成的时间和
    if i == n:
        if f < bestf:
            bestf = f
            bestx = x[:]
        return
    for j in range(i, n):
        f1 += M[x[j]][1]
        f2[i] = max(f1, f2[i - 1]) + M[x[j]][2]
        f += f2[i]
        if f < bestf:
            x[i], x[j] = x[j], x[i]
            backtrack(i + 1)
            x[i], x[j] = x[j], x[i]
        f1 -= M[x[j]][1]
        f -= f2[i]


M = [[0, 0, 0], [0, 2, 1], [0, 3, 1], [0, 2, 3]]  # 牺牲第0行第0列，从下标1开始有效
f = 0  # 记录完成时间和
f1 = 0  # 记录第一台机器的完成时间和
n = len(M)
f2 = [i for i in range(n)]  # 各位置在第二台机器上的完成时间
x = [i for i in range(n)]
bestf = math.inf
bestx = None  # 记录最优解
backtrack(1)
print("最优解为:", bestx)
print("最优值为：", bestf)
