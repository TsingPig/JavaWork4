def find_max(l, r):
    global dic
    if l == r:
        return a[l]
    mid = (l + r) // 2
    l_max = find_max(l, mid)
    r_max = find_max(mid + 1, r)
    if l_max > r_max:
        dic[l_max].append(r_max)
        return l_max
    else:
        dic[r_max].append(l_max)
        return r_max


a = [124, 14, 51, 56, 77, 88, 99, 101, 1, 2, 4, 65, 11]
n = len(a)
dic = {key: [] for key in a}
mx = find_max(0, n - 1)
second = max(dic[mx])
print(second)
a.sort()
print(a)
