def merge(l, r):
    global a
    mid = (l + r) // 2
    a_l = a[l:mid + 1]
    a_r = a[mid + 1:r + 1]
    m, n = len(a_l), len(a_r)
    i = j = 0
    while i < m and j < n:
        if a_l[i] < a_r[j]:
            a[l + i + j] = a_l[i]
            i += 1
        else:
            a[l + i + j] = a_r[j]
            j += 1
    while i < m:
        a[l + i + j] = a_l[i]
        i += 1
    while j < n:
        a[l + i + j] = a_r[j]
        j += 1


def mergeSort(l, r):
    if l < r:
        mid = (l + r) // 2
        mergeSort(l, mid)
        mergeSort(mid + 1, r)
        merge(l, r)


a = [12, 11, 13, 5, 6, 7, 20, 10, 100, 35]
n = len(a)
mergeSort(0, n - 1)
print(a)
