##线性时间选择
import random


def partition(l, r, p):
    global a
    a[p], a[l] = a[l], a[p]
    tmp = a[l]
    i, j = l, r
    while i < j:
        while i < j and a[j] >= tmp:
            j -= 1
        if i < j:
            a[i], a[j] = a[j], a[i]
            i += 1
        while i < j and a[i] <= tmp:
            i += 1
        if i < j:
            a[i], a[j] = a[j], a[i]
            j -= 1
    return i


def select(l, r, k):
    pivot = partition(l, r, random.randint(l, r))  # 随机产生一个基准数，得到一个锚点
    l_cnt = pivot - l + 1  # 小于等于基准数的个数
    if l_cnt == k:
        return a[pivot]
    elif l_cnt > k:
        return select(l, pivot - 1, k)
    else:
        return select(pivot + 1, r, k - l_cnt)


a = [89, 10, 21, 5, 2, 8, 33, 27, 63, 55, 66]
n = len(a)
k = 6
res = select(0, n - 1, k)
print(res)
a.sort()
print(a)
