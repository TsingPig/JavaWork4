import math

mx = math.inf


def prim(u, graph, vertex):
    n = len(vertex)
    sum, tree = 0, []
    closest = [u] * n
    lowcost = [graph[u][v] for v in range(n)]
    lowcost[u] = -1
    for _ in range(n - 1):
        min_v = 0
        min_cost = mx
        for v in range(n):
            if lowcost[v] != -1 and lowcost[v] < min_cost:
                min_v = v
                min_cost = lowcost[v]
        sum += lowcost[min_v]
        tree.append([vertex[closest[min_v]], vertex[min_v], lowcost[min_v]])
        lowcost[min_v] = -1
        for v in range(n):
            if lowcost[v] != -1 and lowcost[v] > graph[min_v][v]:
                lowcost[v] = graph[min_v][v]
                closest[v] = min_v
    return sum, tree


graph = [[0, 54, 32, 7, 50, 60], [54, 0, 21, 58, 76, 69], [32, 21, 0, 35, 67, 66],
         [7, 58, 35, 0, 50, 62], [50, 76, 67, 50, 0, 14], [60, 69, 66, 62, 14, 0]]
vertex = ['A', 'B', 'C', 'D', 'E', 'F']
sum, tree = prim(0, graph, vertex)
for edge in tree:
    print(edge[0] + "--" + edge[1] + "   权:" + str(edge[2]))
print("树的耗费：", sum)
