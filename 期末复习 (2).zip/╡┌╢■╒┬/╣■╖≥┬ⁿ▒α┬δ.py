# 哈夫曼编码 ##################################################################

import heapq


class Node:
    def __init__(self, w, l=None, r=None):
        self.w = w
        self.l = l
        self.r = r

    def __lt__(self, other):
        return self.w < other.w


def build_tree(W):
    h = [Node(w) for w in W]
    heapq.heapify(h)
    while len(h) > 1:
        n1 = heapq.heappop(h)
        n2 = heapq.heappop(h)
        n = Node(n1.w + n2.w, n1, n2)
        heapq.heappush(h, n)
    return h[0]


def encode(n, code):
    if n == None:
        return
    if n.l == None and n.r == None:
        print(str(n.w) +":"+ code)
        return
    encode(n.l, code + "0")
    encode(n.r, code + "1")


def a_len(n, code):
    if n == None:
        return 0
    if n.l == None and n.r == None:
        return n.w / total_w * len(code)
    return a_len(n.l, code + "0") + a_len(n.r, code + "1")


# example usage
W = (5, 29, 7, 8, 14, 23, 3, 11)
n = len(W)
root = build_tree(W)
encode(root, "")

total_w = sum(W)
a_len = a_len(root, "")
print(a_len)
