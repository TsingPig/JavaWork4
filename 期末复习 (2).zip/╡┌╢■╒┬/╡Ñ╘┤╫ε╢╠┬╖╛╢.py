import math

mx = math.inf


def dijkstra(u, graph):
    n = len(graph)  # 集合的大小，即有多少个顶点
    dist, pre, s = [mx] * n, [-1] * n, [False] * n
    dist[u] = 0
    for _ in range(n):
        min_v = -1
        min_w = mx
        for v in range(n):
            if s[v] == False and dist[v] < min_w:  # 找到更小的U-S中的点v
                min_w = dist[v]
                min_v = v
        s[min_v] = True  # 将min_v加入到S集合中
        # 更新所有与min_v关联的点
        for edge in graph[min_v]:
            k, w = edge[0], edge[1]  # 点、边长
            if s[k] == False and dist[k] > min_w + w:
                dist[k] = min_w + w
                pre[k] = min_v
    return dist, pre


data = [
    [1, 0, 8],
    [1, 2, 5],
    [1, 3, 10],
    [1, 6, 9],
    [2, 0, 1],
    [0, 6, 2],
    [3, 6, 5],
    [3, 4, 8],
    [0, 5, 4],
    [5, 6, 7],
    [5, 3, 8],
    [5, 4, 5]]  # 边集合（顶点，顶点，边权）
n = 7  # 图的顶点数n
graph = [[] for _ in range(n)]  # 图的邻接表
# 根据输入的图构建图的邻接表
for edge in data:
    graph[edge[0]].append([edge[1], edge[2]])
    graph[edge[1]].append([edge[0], edge[2]])

dist, pre = dijkstra(1, graph)
print("dist=\n", dist)
print("pre=\n", pre)
