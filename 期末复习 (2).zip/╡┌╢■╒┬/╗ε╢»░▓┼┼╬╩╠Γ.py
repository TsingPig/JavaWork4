activities = {
    'A': (0, 3),
    'B': (1, 5),
    'C': (2, 6),
    'D': (4, 7),
    'E': (5, 9),
    'F': (7, 8),
    'G': (8, 10),
}


def select_activities():
    global activities
    sorted_activities = sorted(activities.items(), key=lambda x: x[1][1], reverse=False)
    pre_end_time = 0
    res = []
    for activity, (start_time, end_time) in sorted_activities:
        if start_time >= pre_end_time:
            res.append((activity, (start_time, end_time)))
            pre_end_time = end_time
    return res


print(f'Selected activities: {select_activities()}')
