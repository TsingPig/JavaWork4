def kruskal(edges, vertexs):
    n = len(vertexs)
    tree = []
    edges.sort(key=lambda x: x[2])
    group = [[i] for i in range(1, 1 + n)]
    for edge in edges:
        m = n = 0
        for i in range(len(group)):
            m = i if edge[0] in group[i] else m
            n = i if edge[1] in group[i] else n
        if m != n:
            tree.append(edge)
            group[m] += group[n]
            group.pop(n)
    return tree


edges = [(1, 2, 6), (1, 3, 1), (1, 4, 5), (2, 3, 5), (2, 5, 3), (3, 4, 5), (3, 6, 4), (3, 5, 6), (4, 6, 2),
         (5, 6, 6)]
vertex = [1, 2, 3, 4, 5, 6]
tree_mst = kruskal(edges, vertex)
for edge in tree_mst:
    print(edge)
