def Ok(i):
    for j in range(1, i):
        if a[i][j] == 1 and x[i] == x[j]:
            return False
    return True


def backtrack(i):
    global colors, x
    if i > n:
        colors.append(x[:])
        return
    for j in range(1, m + 1):
        x[i] = j
        if Ok(i):
            backtrack(i + 1)


a = [[0, 0, 0, 0, 0, 0], [0, 0, 1, 1, 0, 0], [0, 1, 0, 1, 1, 1], [0, 1, 1, 0, 1, 0], [0, 0, 1, 1, 0, 1],
     [0, 0, 1, 0, 1, 0]]
n = len(a) - 1
m = 3
colors = []
x = [0 for i in range(n + 1)]
backtrack(1)
for i in range(len(colors)):
    print(colors[i])
print("共有：" + str(len(colors)) + "种着色方案")
