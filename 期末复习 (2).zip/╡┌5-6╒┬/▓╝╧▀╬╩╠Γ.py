# 布线问题
from collections import deque


class Node:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def __eq__(self, other):
        return self.x == other.x and self.y == other.y


def find_path(a, b):
    global grid
    grid[a.x][a.y] = 0
    q = deque()
    q.append(a)
    while len(q) != 0:
        u = q.popleft()
        for i in range(4):
            v = Node(u.x + offset[i].x, u.y + offset[i].y)
            if grid[v.x][v.y] == -1:
                grid[v.x][v.y] = grid[u.x][u.y] + 1
                if v == b:
                    return
                q.append(v)


def build_path(grid, start, finish):
    global offset
    pathlen = grid[finish.x][finish.y]
    path = []
    here = finish
    for j in range(pathlen - 1, -1, -1):
        path.insert(0, here)
        for i in range(4):
            nbr = Node(here.x + offset[i].x, here.y + offset[i].y)
            if (grid[nbr.x][nbr.y] == j):
                break
        here = nbr
    path.insert(0, start)
    return path, pathlen


n = 9
m = 7
grid = [[-1 for j in range(m + 2)] for i in range(n + 2)]
grid[1][6] = -2
grid[2][3] = -2
grid[3][3] = -2
grid[3][5] = -2
grid[3][6] = -2
grid[4][3] = -2
grid[5][6] = -2
grid[6][5] = -2
grid[6][4] = -2
grid[6][6] = -2
grid[7][6] = -2
grid[9][3] = -2
grid[9][5] = -2
offset = [Node(0, 1), Node(1, 0), Node(0, -1), Node(-1, 0)]
start = Node(3, 2)
finish = Node(6, 7)
for i in range(n + 2):
    grid[i][0] = -2
    grid[i][m + 1] = -2
for i in range(m + 2):
    grid[0][i] = -2
    grid[n + 1][i] = -2

find_path(start, finish)
path, pathlen = build_path(grid, start, finish)
print("布线长度为：", pathlen)
print("布线方案为：")
for i in range(len(path)):
    print("path[" + str(i) + "].x=" + str(path[i].x) + "     path[" + str(i) + "].y=" + str(path[i].y))
