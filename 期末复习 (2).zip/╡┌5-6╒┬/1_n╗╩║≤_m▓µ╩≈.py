# 约束条件：皇后不同列、对角线

def is_valid(board, x, y):
    # 判断x上方的行是否跟(x,y)出现同列或者同对角线
    for i in range(x):
        if board[i] == y or abs(x - i) == abs(board[i] - y):
            return False
    return True


def backtrack(n, board, x):
    # 终止条件
    if x == n:  # 必然只剩一个空列、一个空对角线
        print(board)
        return
    # 回溯
    for i in range(n):
        if is_valid(board, x, i):
            board[x] = i
            backtrack(n, board, x + 1)


def n_queens(n):
    board = [-1] * n
    backtrack(n, board, 0)


n_queens(4)
