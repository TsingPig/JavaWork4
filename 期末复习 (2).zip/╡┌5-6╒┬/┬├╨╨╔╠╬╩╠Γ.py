import math


def backtrack(i):
    global NoEdge, dist, bestc, bestx, cc, n
    N = n - 1  # 问题的规模
    if i >= N:
        if cc + dist[x[N - 1]][x[N]] + dist[x[N]][1] < bestc:
            bestx = x[:]
            bestc = cc + dist[x[N - 1]][x[N]] + dist[x[N]][1]
        return
    for j in range(i, n):
        if cc + dist[x[i - 1]][x[j]] < bestc:
            cc += dist[x[i - 1]][x[j]]
            x[i], x[j] = x[j], x[i]
            backtrack(i + 1)
            x[i], x[j] = x[j], x[i]
            cc -= dist[x[i - 1]][x[j]]

NoEdge = math.inf
dist = [[0, 0, 0, 0, 0, 0], [0, NoEdge, 10, NoEdge, 4, 12], [0, 10, NoEdge, 15, 8, 5],
        [0, NoEdge, 15, NoEdge, 7, 30], [0, 4, 8, 7, NoEdge, 6], [0, 12, 5, 30, 6, NoEdge]]

n = len(dist)
x = [i for i in range(n)]
bestx = None
bestc = NoEdge
cc = 0
backtrack(2)  # 第一个城市固定，所以从第二层开始搜索
print("最短路径长度为：", bestc)
print("最短路径为：", bestx)
