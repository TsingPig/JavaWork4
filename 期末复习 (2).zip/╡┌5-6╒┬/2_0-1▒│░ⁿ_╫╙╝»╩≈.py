def backtrack(i):  # 当前考虑到第i个物品
    global bestV, bestX, cv, cw, x
    if i >= n:  # 终止条件：考虑完所有物品
        if bestV < cv:
            bestV = cv
            bestX = x[:]
        return
    # 回溯
    if cw + w[i] <= M:  # 能装
        x[i] = 1
        cw += w[i]
        cv += v[i]
        backtrack(i + 1)
        cw -= w[i]  # 恢复
        cv -= v[i]

    x[i] = 0
    backtrack(i + 1)


bestV = 0
cw = 0
cv = 0
bestX = None
n = 5
M = 10
w = [2, 2, 6, 5, 4]
v = [6, 3, 5, 4, 6]  # 价值

x = [0] * n  # 解空间
backtrack(0)
print(bestV)
print(bestX)
