package 期末复习.隐藏;

import javax.crypto.spec.OAEPParameterSpec;

/*
隐藏：子类中与父类同名的变量和静态方法构成隐藏。
隐藏访问，在多态中表现为编译时类型。
 */
class A{
    int d=1;
    void display(){
        System.out.println("A_display");
    }
    static void show(){
        System.out.println("A_staic_show");
    }
}
class B extends A{
    int d=2;
    void display(){
        System.out.println("B_diaplay");
    }
    static void show(){
        System.out.println("B_static_show");
    }
}
public class 隐藏 {
    public static void main(String[] args) {
        A a=new B();
        System.out.println(a.d);    //1
        a.display();     //B_display
        A.show();        //A_static_show
        a.show();        //A_static_show
    }
}
