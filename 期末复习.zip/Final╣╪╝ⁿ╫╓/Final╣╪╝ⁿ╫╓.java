package 期末复习.Final关键字;

import java.net.SocketOption;

/*
final:
    1.用于终止类继承、方法重写或隐藏、变量多次赋值
    2.修饰非抽象类、非抽象方法、变量
    3.private方法默认为final类型。
    4.final变量必须在定义或者构造函数中初始化

对比private方法:
    private方法子类无法继承。
    final方法子类只能继承，不能重写、隐藏
 */
final class MyString {
    String content = "str";
}

//final类不允许继承。
//class MyExtendString extends MyString{
//
//}

class Animal {
    int health = 100;
    final String className;
    final String className_2 = "Animal_2";

    Animal() {
        className = "Animal";
    }

    final void Die() {
        System.out.println("die");
        health = 0;
    }

    private void IsAnimal() {
        System.out.println("isAnimal");
    }
}

class Pig extends Animal {
//final方法不允许重写
//    void Die(){
//
//    }


}

public class Final关键字 {
    public static void main(String[] args) {
        Pig p = new Pig();
        p.Die();
        //p.IsAnimal(); private方法子类不能继承

    }
}
