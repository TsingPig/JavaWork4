package 期末复习.抽象类和抽象方法;
/*
抽象类：
    1.可以有非抽象方法并实现
    2.可以没有抽象方法
    3.不能实例化。
    4.需要被继承，作为其他类的规范。
抽象方法：
    1.必须在抽象类中。
    2.抽象类被继承时，子类要么继续抽象，要么需要实现所有抽象方法。
 */

abstract class Graphix {         //抽象类
    void show() {
        System.out.println("Graphix");
    }

    abstract void calArea();    //抽象方法
}

class Rect extends Graphix {
    int s = 1;

    void show() {
        System.out.println("Rect");
    }

    void calArea() {
        //抽象方法实现
        System.out.println(s);
    }
}

public class 抽象类和抽象方法 {
    public static void main(String[] args) {
        // Graphix g=new Graphix();  抽象类，不能实例化
        Rect r = new Rect();
        System.out.println(r.s);    //1
        r.calArea();                //1
        r.show();                   //Rect
        Graphix g = r;              //抽象类可以定义引用变量
        g.calArea();                //1
        g.show();                   //Rect

    }
}
