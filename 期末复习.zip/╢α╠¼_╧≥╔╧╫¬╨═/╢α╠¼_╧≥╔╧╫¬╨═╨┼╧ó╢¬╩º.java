package 期末复习.多态_向上转型;

/*
向上转型：丢失子类新增的成员信息。
        能够访问子类继承或

*/
class A {
    int d = 1;

    void display() {
        System.out.println("A:" + d);
    }
}

class B extends A {
    int d = 20;
    int c = 15;

    void display() {
        System.out.println("B:" + d);
    }

    void display_super() {
        System.out.println("B_super" + super.d);
    }
}


public class 多态_向上转型信息丢失 {
    public static void main(String[] args) {
        A a = new B();
        //System.out.println(a.c);    //不可以，向上转型丢失子类变量信息
        //a.display_super();        //同理不可以，丢失子类方法信息
        System.out.println(a.d);    //1
        a.display();                //20
        B b = (B) a;    //强制向下转型
        System.out.println(b.d);    //20
        b.display();   //20


    }
}
