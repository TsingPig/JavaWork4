package 期末复习.抽象类练习;

abstract class UI {
    static int count = 0;
    UI() {
        count++;
    }

    abstract void Function();
}

class Button extends UI {
    void Function() {
        System.out.println("这是按钮");
    }

}

class Toggle extends UI {
    void Function() {
        System.out.println("这是勾选框");
    }
}

public class 抽象类练习_统计抽象子类实例对象个数 {
    public static void main(String[] args) {
        Button b1 = new Button();
        Toggle t1 = new Toggle();
        Toggle t2 = new Toggle();
        System.out.println(UI.count);
    }
}
