package 期末复习.多态_向下转型;

/*
向下转型条件：
    引用对象
    编译时类型为父类；
    运行时类型为子类。
 */
class A {
    int d = 100000;
    int aa = 9999;

    void show() {
        System.out.println("A");
    }
}

class B extends A {
    int d = 2;
    int bbbbb = 1;

    void show() {
        System.out.println("B");
    }
}

public class 多态_向下转型 {
    public static void main(String[] args) {
        A a = new A();
        B b = new B();
        //b = (B) a;  错误的向下转型
        a = new B();

        B b2 = (B) a;   //正确的向下转向。回复信息
        b2.show();

    }
}
