package 期末复习.多态_编译时类型和运行时类型;


/*


编译时类型：变量声明的类型。
运行时类型：变量实际指向的类型。
当编译时类型、运行时类型不一致，出现多态——
    子类对象赋值给父类引用变量（向上转型）

访问时，父类引用变量时，实例变量(非静态的数据成员)由编译时类型决定；
                       方法由运行时类型决定。

变量隐藏：子类声明与父类同名的实例变量。
*/
class A {
    int d = 1;

    void display() {
        System.out.print("类A");
    }
}

class B extends A {
    int d = 2;

    void display() {
        System.out.print("类B");
    }
}

public class 多态_编译时类型和运行时类型 {
    public static void main(String[] args) {
        A a = new B();
        System.out.println(a.d);
        a.display();
    }
}
