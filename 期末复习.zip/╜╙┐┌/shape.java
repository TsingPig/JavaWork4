package 期末复习.接口;

/*
接口:
    1.包含方法声明、常量、默认方法
    2.方法默认且只能为public abstract；
        常量默认且只能为public static abstract
    3.可以继承一个或多个接口
    4.不能实例化
    5.可以定义接口引用变量
实现接口的类：
    1.可以实现多个接口，逗号分隔
    2.必须提供接口所有方法的实现

 */
public interface shape {
    double getArea();
}
