package 期末复习.接口;

class Circle implements shape {

    public double getArea() {

        return 0;
    }
}


public class 接口 {
}
